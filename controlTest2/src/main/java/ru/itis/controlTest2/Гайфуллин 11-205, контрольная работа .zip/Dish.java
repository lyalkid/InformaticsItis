package ru.itis.controlTest2;

public class Dish {
    String x;
    Dish(){
        x = "Рис с курчкой";
    }
}
