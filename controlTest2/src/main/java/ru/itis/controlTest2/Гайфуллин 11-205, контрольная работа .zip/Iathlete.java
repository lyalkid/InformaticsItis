package ru.itis.controlTest2;

public interface Iathlete {
    void eat();
    void sleep();
    void train();
}
