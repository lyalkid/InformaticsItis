package ru.itis.controlTest2;

public abstract class Athlete implements Iathlete {
    public abstract void eat();
    public abstract void sleep();
    public abstract void train();

}
