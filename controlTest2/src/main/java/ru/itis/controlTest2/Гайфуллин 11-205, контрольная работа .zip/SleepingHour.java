package ru.itis.controlTest2;

public class SleepingHour {
    int x;
    SleepingHour(int i){
        x = i;
    }
}
